import Page from 'components/Page';
import SearchInput from 'components/SearchInput';
import React from 'react';
import ReactDOM from 'react-dom';
import {
  Button,
  Badge,
  Card,
  CardBody,
  CardHeader,
  Col,
  Row,
  Table,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Input,
  Label,
  InputGroup,
  InputGroupAddon,
  Form,
  UncontrolledButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  ListGroup,
  ListGroupItem,
  UncontrolledDropdown,
  FormGroup,
} from 'reactstrap';
import {
  MdSearch,
  MdLoyalty,
  MdFormatAlignRight,
  MdHome,
} from 'react-icons/md';
import NotificationSystem from 'react-notification-system';
import { NOTIFICATION_SYSTEM_STYLE } from 'utils/constants';
import DropdownPage from '../template/DropdownPage';
import { timingSafeEqual } from 'crypto';

const hostUrl = 'http://10.0.111.143:8070';
class ApotikPage extends React.Component {
  //special method
  constructor(props) {
    super(props);
    this.state = {
      result: [],
      searchOutletList: [],
      dataSearchs: [],
      isLoading: false,
      inputtedName: '',
      inputtedName2: '',
      searchInputtedName: '',
      currentPage: 0,
      todosPerPage: 5,
      flag: 0,
      totalPage: '',
      hidePagination: 'flex-row',
      selectedDropdown: 'Show All',
      inputSearch: 'inline',
      tableNOSP: 'd-none',
      isHovering: false,
    };
    this.searchInnerRef = React.createRef();
    this.handleMouseHover = this.handleMouseHover.bind(this);
  }
  //fungsi notification
  showNotification = currMessage => {
    setTimeout(() => {
      if (!this.notificationSystem) {
        return;
      }
      this.notificationSystem.addNotification({
        title: <MdLoyalty />,
        message: currMessage,
        level: 'info',
      });
    }, 100);
  };

  // ----------------------------------------------- PAGINATION SHOW ALL DATA --------------------------------------------------------- EDITED BY RICHARD & DANIEL & KRIS

  //Memberikan semua list data pada page tersebut dimana diBack end mempunyai data Current limit maupun Current Page

  getListbyPaging(currPage, currLimit) {
    this.setState({
      isLoading: true,
    });

    var url =
      hostUrl + `/TampilDeliveryOrder/page?page=${currPage}&size=${currLimit}`;

    console.log('masuk TampilDeliveryOrder Show All');
    console.log(url);
    this.isLoading = true;
    fetch(url)
      .then(response => response.json())
      .then(data => {
        if (data.transfD === null) {
          this.setState({
            result: [],
            isLoading: false,
            totalPage: data.totalPages,
          });
        } else {
          this.setState({
            result: data.content,
            isLoading: false,
            totalPage: data.totalPages,
          });
        }
      });
  }

  //fungsi untuk mengambil semua data dimana memanggil current page dan perpage
  componentDidMount() {
    this.getListbyPaging(this.state.currentPage, this.state.todosPerPage);
  }

  handleSelect(event) {
    this.setState({ [event.target.name]: event.target.value }, () => {
      this.getListbyPaging(this.state.currentPage, this.state.todosPerPage);
    });
  }

  handleWrite(event, flag) {
    if (
      this.state.currentPage + flag < 1 ||
      this.state.currentPage + flag > this.state.totalPage - 1
    ) {
      return;
    }
    this.setState(
      {
        currentPage: Number(event.target.value) + flag,
      },
      () => {
        if (flag !== 0) {
          this.searchCodetoSP(this.state.currentPage, this.state.todosPerPage);
        }
      },
    );
  }

  //fungsi yang mengarah kan ke arah first page
  handleFirst(event) {
    this.setState({
      currentPage: 0,
    });
    this.getListbyPaging(0, this.state.todosPerPage);
  }

  //fungsi yang mengarah ke arah last page
  handleLast(event) {
    this.setState({
      currentPage: this.state.totalPage - 1,
    });
    this.getListbyPaging(this.state.totalPage - 1, this.state.todosPerPage);
  }

  handleClose = () => {
    this.setState({
      inputtedName2: '',
    });
  };
  //state awal pada saat membuka suatu page tsb nanti dicari langsung di render()
  state = {
    modal: false,
    modal_backdrop: false,
    modal_nested_parent: false,
    modal_nested: false,
    modal_delete: false,
    modal_update: false,
    backdrop: true,
    inputtedName2: '',
  };

  handleMouseHover() {
    this.setState(this.toggleHoverState);
  }

  toggleHoverState(state) {
    return {
      isHovering: !state.isHovering,
    };
  }

  //fungsi untuk membuka suatu toggle di page tsb
  toggle = modalType => () => {
    if (!modalType) {
      return this.setState({
        modal: !this.state.modal,
      });
    }

    //pembuatan setState disemua function, dimana hanya memanggil nama nya saja ex modal_delete , maka di render hanya panggil delete saja
    this.setState({
      [`modal_${modalType}`]: !this.state[`modal_${modalType}`],
    });
  };

  // --------------------------------------------------------- SEARCH --------------------------------------------------------- EDITED BY RICHARD & DANIEL & KRISS

  //mengambil parameter yang telah diinput di searchInputtedName . lalu dilempar ke Backend
  searchInputted = async () => {
    if (this.state.outletSearch !== null) {
      this.setState({ isLoading: true });
      var url = `http://10.0.111.143:8070/CariDeliveryOrder`;
      var payload = {
        category: this.state.searchDropdownValue,
        search: this.state.outletSearch,
      };

      let data = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json;charset=utf-8',
        },
        json: true,
        body: JSON.stringify(payload),
      })
        .then(response => response.json())
        .then(data => {
          try {
            this.setState({ searchOutletList: data, isLoading: false });
          } catch (error) {
            this.setState({
              hidePagination: 'd-none',
            });
            console.log(data);
          }
        });
    }
  };

  getSearch() {
    this.setState({ isLoading: true });
    var url = hostUrl + `/TampilOption`;
    console.log(url);
    fetch(url)
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          console.log('RESPONSE NOT FOUND');
        }
      })
      .then(data => {
        let dataSearch = data.map(dataSearch => {
          console.log(dataSearch);
          return {
            value: dataSearch.id,
            display: dataSearch.name,
          };
        });

        this.setState({
          isLoading: false,
          dataSearchs: [{ value: '', display: '' }].concat(dataSearch),
        });
      })
      .catch(() => {
        console.log('ERROR Pencairan');
      });
  }

  handleFind = evt => {
    const value = evt.target.value;
    const name = evt.target.name;
    console.log('name ' + name + value);
    this.setState(
      {
        searchDropdown: name,
        searchDropdownValue: value,
      },
      () => console.log('searchDropdownValue' + this.state.searchDropdownValue),
    );
  };

  //function untuk melakukan search pada saat menekan enter
  enterPressed = (event, search) => {
    var code = event.keyCode || event.which;
    if (code === 13) {
      console.log('MASUK ENTER PRESSED');
      this.searchInputted();
      this.setState({
        currentPage: 0,
      });
    }
  };

  searchCodetoSP = (OutcodeDest, UserID) => {
    this.setState({ isLoading: true, disableClickSearchOutlet: true });
    console.log(this.state.currentPage + 'currentPagesearchCODETOSP');
    var url =
      hostUrl +
      `/TampilDeliveryOrder/page?page=${this.state.currentPage}&code=${OutcodeDest}&name=${UserID}`;
    console.log(url);
    fetch(url)
      .then(response => response.json())
      .then(data => {
        try {
          this.setState({
            result: data.content,
            isLoading: false,
            tableNOSP: 'inline',
            modal_outletSearch: false,
          });
        } catch (err) {
          console.log('ERR: ' + err.message);
          this.setState({
            isLoading: false,
            tableNOSP: 'd-none',
            modal_outletSearch: true,
          });
        }
      });
  };

  searchCodeApotik = evt => {
    console.log(evt.target);
    this.setState({
      outletSearch: evt.target.value.replace(/[^\w\s]/gi, '').toUpperCase(),
    });
  };

  //ketika melakukan search, state input-an yang masuk harus uppercase dan tidak boleh special character
  setSearchInputState = evt => {
    this.setState({
      searchInputtedName: evt.target.value
        .replace(/[^\w\s]/gi, '')
        .toUpperCase(),
    });
  };

  //--------------------------------------------------------- DELETE --------------------------------------------------------- EDITED BY RICHARD & DANIEL & KRISS

  openModalOnClick() {
    var namaLokasied = document.getElementById('namaLokasi');

    this.setState({});
    if (this.state.inputtedName2.length >> 0) {
      this.setState({ modal_nested: true });
    } else {
      namaLokasied.oninvalid = true;
      this.setState({ modal_nested: false });
    }
  }

  onClickSearchOutlet() {
    const isOpen = this.state.modal_outletSearch;
    this.getSearch();
    this.setState(
      {
        searchDropdown: 'PIC',
        searchDropdownValue: 'UserID',
        modal_outletSearch: !isOpen,
        outletSearch: 'RICHARD',
      },
      () => {
        if (!isOpen) this.searchInnerRef.current.focus();
      },
    );
  }

  //render biasa nya di-isi untuk desain HTML
  render() {
    const { result, isLoading } = this.state;
    return (
      <Page
        title="SP DO Apotik"
        breadcrumbs={[{ name: 'SP DO Apotik', active: true }]}
        className="SP DO"
      >
        <Card className="mb-3">
          <NotificationSystem
            dismissible={false}
            ref={notificationSystem =>
              (this.notificationSystem = notificationSystem)
            }
            style={NOTIFICATION_SYSTEM_STYLE}
          />
          {/* ======================================INPUT SEARCH============================== */}
          <CardHeader className="d-flex justify-content-between">
            <Form inline className="cr-search-form">
              {/* ======================================CLICK SEARCH============================== */}
              <InputGroup>
                <Button
                  id="onClickSearch"
                  placeholder=""
                  className={this.state.inputSearch}
                  onSubmit={e => e.preventDefault()}
                  value={this.state.searchInputtedName}
                  onClick={() => this.onClickSearchOutlet()}
                >
                  <MdSearch></MdSearch>{' '}
                </Button>
              </InputGroup>
            </Form>
            <Col className="ml-3">
              <Button class="ml-5 mt-2" size="25px" href={'./spdo'}>
                MAIN MENU
                <MdHome className="mb-1 ml-1" size="20px"></MdHome>
              </Button>
            </Col>

            {/* ======================================KETIKA TAMBAH DATA============================== */}
            <Modal
              isOpen={this.state.modal_outletSearch}
              toggle={this.toggle('outletSearch')}
              className="modal-dialog-scrollable modal-dialog-centered"
              size="lg"
              backdrop="static"
            >
              <ModalBody>
                <Row>
                  <Col xs={8} md={5}>
                    <Label>Search</Label>
                  </Col>
                  <Col xs={8} md={5}>
                    <FormGroup>
                      <UncontrolledDropdown direction="down">
                        <DropdownToggle caret>
                          {this.state.searchDropdown}
                        </DropdownToggle>
                        <DropdownMenu>
                          {this.state.dataSearchs.map(dataSearch => (
                            <DropdownItem
                              style={{ maxHeight: '40px' }}
                              name={dataSearch.display}
                              value={dataSearch.value}
                              onClick={event => this.handleFind(event)}
                            >
                              {dataSearch.display}
                            </DropdownItem>
                          ))}
                        </DropdownMenu>
                      </UncontrolledDropdown>
                    </FormGroup>
                  </Col>
                </Row>
                <InputGroup>
                  <Input
                    type="search"
                    innerRef={this.searchInnerRef}
                    name="outletSearchInput"
                    placeholder="Cari"
                    value={this.state.outletSearch}
                    disabled={this.state.isLoading}
                    onKeyPress={event => this.enterPressed(event)}
                    onChange={this.searchCodeApotik}
                  />
                  <InputGroupAddon addonType="append">
                    <Button onClick={() => this.searchInputted()}>
                      <MdSearch />
                    </Button>
                  </InputGroupAddon>
                </InputGroup>

                <p
                  className={
                    (this.state.searchOutletList.length > 0 ? '' : 'd-none') +
                    ' text-center font-weight-bold mt-3'
                  }
                >
                  Pilih Salah Satu !
                </p>

                <Table
                hover
                
                style={{ cursor:'pointer' }}
                className={
                    this.state.searchOutletList.length > 0 ? '' : 'd-none'
                  }
                  striped
                >
                  <thead>
                    <tr align="center">
                      <th>CODE</th>
                      <th>PIC</th>
                      <th>OUTLET</th>
                    </tr>
                  </thead>

                  <tbody>
                    {this.state.searchOutletList.map(outlist => (
                      <tr
                        disabled={this.state.disableClickSearchOutlet}
                        tag="button"
                        name={outlist.outlet}
                        value={outlist.OutcodeDest}
                        onClick={() =>
                          this.searchCodetoSP(
                            outlist.OutcodeDest,
                            outlist.UserID.substr(
                              outlist.UserID.indexOf('@') + 1,
                            ),
                          )
                        }
                      >
                        <td>{outlist.OutcodeDest}</td>
                        <td align="center">{outlist.pembuat}</td>
                        <td align="center">{outlist.outlet}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </ModalBody>
              <ModalFooter>
                <Button
                  style={{
                    background: '#FF0000',
                    borderStyle: 'none',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                  disabled={this.state.isLoading}
                  onClick={this.toggle('outletSearch')}
                >
                  Cancel
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              //isOpen={this.state.modal_nested_parent}
              toggle={this.toggle('nested_parent')}
              className={this.props.className}
              onExit={this.handleClose}
            >
              <ModalHeader toggle={this.toggle('nested_parent')}>
                Tambah Group Pemilik Lokasi
              </ModalHeader>
              <ModalBody>
                <Label>Nama Lokasi</Label>

                <Input
                  id="namaLokasi"
                  type="Nama Lokasi"
                  value={this.state.inputtedName2}
                  onChange={evt => this.insertInputValue(evt)}
                  name="namalokasi"
                  placeholder="Nama Group Pemilik Lokasi"
                />
              </ModalBody>
              <ModalFooter>
                <Button
                  id="buttonSimpan"
                  color="primary"
                  onClick={() => this.openModalOnClick()}
                >
                  Simpan
                </Button>
                
                <Button color="primary" onClick={this.toggle('nested_parent')}>
                  Batal
                </Button>
              </ModalFooter>
            </Modal>

            {/* ======================================KETIKA DELETE DATA(NON-AKTIF DATA YANG AKTIF)============================== */}
            
            {/* ======================================KETIKA EDIT/UPDATE DATA============================== */}
                  
          </CardHeader>

          <CardBody>
            <Table
              className={this.state.tableNOSP}
              responsive
              id="selectedColumn"
              class="table table-striped table-bordered table-sm "
              cellspacing="0"
              width="100%"
            >
              {/* ================= TABLE DATA DIMANA LIST DATA YANG MUNCUL (TELAH DI DAPAT DR DATABASE)============================= */}
              <CardHeader>
                <Row>
                  <Col sm={2} md={2} style={{ fontWeight: 'bold' }}>
                    <label>NO DO</label>
                  </Col>
                  <Col sm={2} md={2} style={{ fontWeight: 'bold' }}>
                    <label>TGL DO</label>
                  </Col>
                  <Col sm={2} md={2} style={{ fontWeight: 'bold' }}>
                    <label>NO SP</label>
                  </Col>
                  <Col sm={2} md={2} style={{ fontWeight: 'bold' }}>
                    <label>OUTLET</label>
                  </Col>
                  <Col sm={2} md={2} style={{ fontWeight: 'bold' }}>
                    <label>PRINT</label>
                  </Col>
                  <Col sm={3} md={2} style={{ fontWeight: 'bold' }}>
                    <label>Pembuat</label>
                  </Col>
                </Row>
              </CardHeader>
              {result.map(spdo => (
                <Card
                  outline
                  color="secondary"
                  className="mb-1"
                  borderRadius={5}
                >
                  <CardBody
         
               on
                  >
                    <Row>
                      <Col style={{ fontWeight: 'bold' }}>{spdo.no_do}</Col>
                      <Col>{spdo.Tgltransf}</Col>
                      <Col style={{ fontWeight: 'bold' }}>{spdo.No_SP}</Col>
                      <Col>{spdo.outlet}</Col>
                      <Col>{spdo.Flag}</Col>
                      <Col>{spdo.pembuat}</Col>
                    </Row>
                  </CardBody>
                </Card>
              ))}
            </Table>
            <Row className={this.state.tableNOSP}>
              {/* ==================== PEMBERIAN LIMIT DATA PER HALAMAN============================== */}
              <Col md="6" sm="12" xs="12">
                <InputGroup>
                  <InputGroupAddon addonType="prepend">
                    Data per Halaman
                  </InputGroupAddon>
                  <select
                    name="todosPerPage"
                    style={{ height: '38px' }}
                    value={this.state.value}
                    onChange={e => this.handleSelect(e)}
                  >
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="20">20</option>
                  </select>
                </InputGroup>
              </Col>

              <Col md="6" sm="12" xs="12" f>
                <InputGroup style={{ width: '243px' }}>
                  <div className="input-group-prepend">
                    {/* ====================================== FIRST PAGE ============================== */}
                    <Button
                      style={{
                        background: '#2CB7A4',
                        borderStyle: 'none',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      className="btn btn-info"
                      value={this.state.currentPage}
                      onClick={e => this.handleFirst(e, -1)}
                    >
                      &lt;&lt;
                    </Button>
                    {/* ====================================== BACK ============================== */}
                    <Button
                      style={{
                        background: '#2CB7A4',
                        borderStyle: 'none',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      className="btn btn-info"
                      value={this.state.currentPage}
                      onClick={e => this.handleWrite(e, -1)}
                    >
                      &lt;
                    </Button>
                  </div>

                  <span
                    className="text-muted p-2 "
                    style={{
                      height: '10px',
                      width: '100px',
                      textAlign: 'center',
                    }}
                  >
                    {this.state.currentPage + 1}
                  </span>
                  {/* ====================================== NEXT  ============================== */}
                  <div className="input-group-append">
                    <Button
                      style={{
                        background: '#2CB7A4',
                        borderStyle: 'none',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      className="btn btn-info"
                      value={this.state.currentPage}
                      onClick={e => this.handleWrite(e, 1)}
                    >
                      &gt;
                    </Button>
                    {/* ====================================== LAST PAGE  ============================== */}
                    <Button
                      style={{
                        background: '#2CB7A4',
                        borderStyle: 'none',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      className="btn btn-info"
                      value={this.state.currentPage}
                      onClick={e => this.handleLast(e)}
                    >
                      &gt;&gt;
                    </Button>
                  </div>
                </InputGroup>
              </Col>
            </Row>
          </CardBody>
        </Card>
      </Page>
    );
  }
}
export default ApotikPage;
