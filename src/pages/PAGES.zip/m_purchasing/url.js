var url_tampil_kemasan = "http://10.0.111.169:8085/MasterKemasan/TampilSemuaKemasan";
// export default url_tampil_kemasan

var url_cari_kodekemasan = "http://10.0.111.169:8085/MasterKemasan/CariKodeKemasan";
// export default url_cari_kodekemasan

var url_cari_namakemasan = "http://10.0.111.169:8085/MasterKemasan/CariNamaKemasan";
// export default url_cari_namakemasan

var url_tambah_kemasan = "http://10.0.111.169:8085/MasterKemasan/TambahKemasan";
// export default url_tambah_kemasan

var url_edit_kemasan = "http://10.0.111.169:8085/MasterKemasan/EditKemasan";
// export default url_edit_kemasan

var url_hapus_kemasan = "http://10.0.111.169:8085/MasterKemasan/HapusKemasan";
// export default url_hapus_kemasan 

var url_tampil_kemasan_limit = 'http://10.0.111.169:8085/MasterKemasan'




export {url_tampil_kemasan, url_tampil_kemasan_limit, url_cari_kodekemasan,url_cari_namakemasan
    ,url_tambah_kemasan,url_edit_kemasan,url_hapus_kemasan};